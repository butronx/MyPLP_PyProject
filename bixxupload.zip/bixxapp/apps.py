from django.apps import AppConfig


class BixxappConfig(AppConfig):
    name = 'bixxapp'
